# IR Timeline - AI E-Reader Assessment (sanitised)
- T+00:00 - Phishing simulation / token extraction test executed on test host.
- T+00:05 - Token replay request observed from different IP in pcap.
- T+00:10 - Application logs show repeated access to protected content ID=1234.
- T+00:15 - Containment: revoke active tokens and rotate keys, enable rate-limiting.
- T+00:30 - Evidence packaged: pcap, sanitized storage snapshot, app logs.
- T+01:00 - Remediation plan delivered to dev team.
